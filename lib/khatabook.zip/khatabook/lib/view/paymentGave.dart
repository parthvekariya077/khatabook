import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:khatabook/controller/homeController.dart';
import 'package:khatabook/view/db.dart';

class PaymentGave extends StatefulWidget {
  const PaymentGave({Key? key}) : super(key: key);

  @override
  State<PaymentGave> createState() => _PaymentGaveState();
}

class _PaymentGaveState extends State<PaymentGave> {
  TextEditingController txtpname = TextEditingController();
  TextEditingController txtprice = TextEditingController();
  TextEditingController txtdate = TextEditingController();
  TextEditingController txttime = TextEditingController();

  HomeController homeController = Get.put(HomeController());

  dbClient dbc = dbClient();

  void getData() async {
    homeController.productList.value = await dbc.productreadData(id:homeController.data!.id!);
    homeController.addition();
    homeController.homeAddition();
  }
  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: Text("Add Payment"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: txtpname,
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(),
                hintText: "Enter Product Name",
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: txtprice,
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.currency_rupee),
                border: OutlineInputBorder(),
                hintText: "Enter Price",
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: txtdate,
              decoration: InputDecoration(
                prefixIcon: IconButton(
                    onPressed: () async {
                      datepikerDilog();
                    },
                    icon: Icon(Icons.date_range)),
                border: OutlineInputBorder(),
                hintText: "Enter Date",
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: txttime,
              decoration: InputDecoration(
                prefixIcon:
                    IconButton(onPressed: () {
                      timepickerdilog();
                    }, icon: Icon(Icons.timelapse)),
                border: OutlineInputBorder(),
                hintText: "Enter Time",
              ),
            ),
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.all(15),
                child: Container(
                    height: 50,
                    width: 150,
                    child: ElevatedButton(
                      onPressed: () {
                        Get.back();
                      },
                      child: Text("CANCEL"),
                    )),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: Container(
                    height: 50,
                    width: 150,
                    child: ElevatedButton(
                      onPressed: () {
                        dbc.productinsertData(
                            txtpname.text,
                            txtprice.text,
                            txtdate.text,
                            txttime.text,
                            int.parse(homeController.data!.id!),
                          1
                        );
                        getData();
                        Get.back();
                      },
                      child: Text("SAVE"),
                    )),
              ),
            ],
          ),
        ],
      ),
    ));
  }
  void datepikerDilog() async {
    var date = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2001),
        lastDate: DateTime(3000));
    homeController.getData(date);
    if (date != null) {
      txtdate.text = DateFormat('dd-MM-yyyy').format(date);
    }
  }

  void timepickerdilog() async {
    TimeOfDay? t1 =
    await showTimePicker(context: context, initialTime: TimeOfDay.now());

    if (t1 != null) {
      DateTime parsedtime =
      DateFormat.jm().parse(t1.format(context).toString());

      String formetdtime = DateFormat('hh:mm').format(parsedtime);

      txttime.text = formetdtime;
    }
  }
}
