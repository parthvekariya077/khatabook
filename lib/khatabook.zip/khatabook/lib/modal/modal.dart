class Modal{
  String? id,name,mobile;

  Modal({this.name,this.id, this.mobile});
}
class productModal
{
  String? date,time,name,price;
  String? id;

  productModal({this.id,this.date, this.time, this.name, this.price});
}

